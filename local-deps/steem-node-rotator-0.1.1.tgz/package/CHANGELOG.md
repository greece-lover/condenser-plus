# Changelog

All notable changes to this project will be documented in this file. The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/), and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.1.0] — 2026-04-26

Initial release.

### Added
- `SteemRotator` with auto-failover across configured Steem RPC nodes.
- `NodeHealthRegistry` with cooldown after failures and three pick strategies (`fastest-healthy`, `round-robin`, `first-healthy`).
- `HealthCheckLoop` for background probes; `skipWhenHidden` to avoid mobile battery drain.
- `beginBroadcastSession()` for sticky single-node broadcast (ref-block + broadcast on the same node).
- Optional persistent storage of last known latencies (`localStorage`, `sessionStorage`, or any compatible interface).
- Lifecycle callbacks: `onNodeFailure`, `onNodeRecovery`.
- TypeScript types shipped in-package.
- Browser IIFE bundle, ESM and CJS builds. < 4 KB gzipped for the ESM build.

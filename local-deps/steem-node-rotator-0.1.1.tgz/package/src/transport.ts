import type { JsonRpcRequest, JsonRpcResponse } from './types';
import { NodeRequestError, RpcError, TimeoutError } from './errors';

let requestId = 0;
const nextId = (): number => {
  requestId = (requestId + 1) % 1_000_000_000;
  return requestId;
};

export interface RpcCallParams {
  url: string;
  method: string;
  params: unknown;
  timeoutMs: number;
  fetchImpl: typeof fetch;
  signal?: AbortSignal;
}

export interface RpcCallResult<T> {
  result: T;
  latencyMs: number;
}

export async function rpcCall<T = unknown>(opts: RpcCallParams): Promise<RpcCallResult<T>> {
  const body: JsonRpcRequest = {
    jsonrpc: '2.0',
    id: nextId(),
    method: opts.method,
    params: opts.params
  };

  const controller = new AbortController();
  const timeoutHandle = setTimeout(() => controller.abort(), opts.timeoutMs);
  if (opts.signal) {
    if (opts.signal.aborted) controller.abort();
    else opts.signal.addEventListener('abort', () => controller.abort(), { once: true });
  }

  const start = Date.now();
  let response: Response;
  try {
    response = await opts.fetchImpl(opts.url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
      body: JSON.stringify(body),
      signal: controller.signal
    });
  } catch (err: unknown) {
    clearTimeout(timeoutHandle);
    const e = err as { name?: string; message?: string };
    if (e?.name === 'AbortError') {
      throw new TimeoutError(opts.timeoutMs, opts.url);
    }
    throw new NodeRequestError(opts.url, e?.message ?? 'network error', err);
  }
  clearTimeout(timeoutHandle);

  if (!response.ok) {
    throw new NodeRequestError(opts.url, `HTTP ${response.status}`, response.status);
  }

  let payload: JsonRpcResponse<T>;
  try {
    payload = (await response.json()) as JsonRpcResponse<T>;
  } catch (err: unknown) {
    const e = err as { message?: string };
    throw new NodeRequestError(opts.url, `invalid JSON response: ${e?.message ?? 'parse error'}`, err);
  }

  if (payload.error) {
    throw new RpcError(payload.error.code, payload.error.message, payload.error.data);
  }
  if (payload.result === undefined) {
    throw new NodeRequestError(opts.url, 'response missing result field');
  }

  return { result: payload.result, latencyMs: Date.now() - start };
}

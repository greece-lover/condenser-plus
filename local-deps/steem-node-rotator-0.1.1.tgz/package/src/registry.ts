import type {
  NodeHealth,
  PersistentStorage,
  NodeFailureInfo,
  NodeRecoveryInfo,
  NodePickStrategy
} from './types';

export interface RegistryOptions {
  cooldownMs: number;
  storage?: PersistentStorage | null;
  storageKey?: string;
  pickStrategy?: NodePickStrategy;
  onNodeFailure?: (info: NodeFailureInfo) => void;
  onNodeRecovery?: (info: NodeRecoveryInfo) => void;
}

export class NodeHealthRegistry {
  private readonly nodes = new Map<string, NodeHealth>();
  private readonly order: string[];
  private readonly cooldownMs: number;
  private readonly storage: PersistentStorage | null;
  private readonly storageKey: string;
  private readonly pickStrategy: NodePickStrategy;
  private readonly onNodeFailure?: (info: NodeFailureInfo) => void;
  private readonly onNodeRecovery?: (info: NodeRecoveryInfo) => void;
  private rrCursor = 0;

  constructor(nodeUrls: string[], opts: RegistryOptions) {
    if (nodeUrls.length === 0) {
      throw new Error('NodeHealthRegistry requires at least one node URL');
    }
    this.order = [...nodeUrls];
    this.cooldownMs = opts.cooldownMs;
    this.storage = opts.storage ?? null;
    this.storageKey = opts.storageKey ?? 'steem-node-rotator:health';
    this.pickStrategy = opts.pickStrategy ?? 'fastest-healthy';
    this.onNodeFailure = opts.onNodeFailure;
    this.onNodeRecovery = opts.onNodeRecovery;

    for (const url of nodeUrls) {
      this.nodes.set(url, {
        url,
        isHealthy: true,
        latencyMs: null,
        lastSuccessAt: null,
        lastFailureAt: null,
        cooldownUntil: null,
        failureReason: null,
        consecutiveFailures: 0
      });
    }

    this.loadFromStorage();
  }

  list(): NodeHealth[] {
    return this.order.map(url => ({ ...this.nodes.get(url)! }));
  }

  get(url: string): NodeHealth | undefined {
    const h = this.nodes.get(url);
    return h ? { ...h } : undefined;
  }

  markHealthy(url: string, latencyMs: number, now: number = Date.now()): void {
    const h = this.nodes.get(url);
    if (!h) return;
    const wasUnhealthy = !h.isHealthy;
    h.isHealthy = true;
    h.latencyMs = latencyMs;
    h.lastSuccessAt = now;
    h.cooldownUntil = null;
    h.failureReason = null;
    h.consecutiveFailures = 0;
    this.persist();
    if (wasUnhealthy && this.onNodeRecovery) {
      try { this.onNodeRecovery({ url, latencyMs }); } catch { /* swallow */ }
    }
  }

  markUnhealthy(url: string, reason: string, now: number = Date.now()): void {
    const h = this.nodes.get(url);
    if (!h) return;
    h.isHealthy = false;
    h.lastFailureAt = now;
    h.cooldownUntil = now + this.cooldownMs;
    h.failureReason = reason;
    h.consecutiveFailures += 1;
    this.persist();
    if (this.onNodeFailure) {
      try {
        this.onNodeFailure({ url, reason, consecutiveFailures: h.consecutiveFailures });
      } catch { /* swallow */ }
    }
  }

  /**
   * Returns nodes eligible for use right now (healthy OR cooldown expired),
   * ordered by the configured pick strategy.
   */
  getEligible(now: number = Date.now()): NodeHealth[] {
    const eligible = this.order
      .map(url => this.nodes.get(url)!)
      .filter(h => h.isHealthy || (h.cooldownUntil !== null && h.cooldownUntil <= now));

    if (this.pickStrategy === 'fastest-healthy') {
      return eligible.sort((a, b) => {
        const aL = a.latencyMs ?? Number.POSITIVE_INFINITY;
        const bL = b.latencyMs ?? Number.POSITIVE_INFINITY;
        return aL - bL;
      }).map(h => ({ ...h }));
    }
    if (this.pickStrategy === 'round-robin') {
      const out: NodeHealth[] = [];
      for (let i = 0; i < eligible.length; i++) {
        out.push({ ...eligible[(this.rrCursor + i) % eligible.length] });
      }
      this.rrCursor = (this.rrCursor + 1) % Math.max(1, eligible.length);
      return out;
    }
    return eligible.map(h => ({ ...h }));
  }

  pickPreferred(now: number = Date.now()): NodeHealth | null {
    const eligible = this.getEligible(now);
    return eligible.length > 0 ? eligible[0] : null;
  }

  reset(): void {
    for (const url of this.order) {
      this.nodes.set(url, {
        url,
        isHealthy: true,
        latencyMs: null,
        lastSuccessAt: null,
        lastFailureAt: null,
        cooldownUntil: null,
        failureReason: null,
        consecutiveFailures: 0
      });
    }
    this.rrCursor = 0;
    this.persist();
  }

  private loadFromStorage(): void {
    if (!this.storage) return;
    try {
      const raw = this.storage.getItem(this.storageKey);
      if (!raw) return;
      const parsed = JSON.parse(raw) as { nodes?: Record<string, Partial<NodeHealth>> };
      if (!parsed || typeof parsed !== 'object' || !parsed.nodes) return;
      for (const [url, snap] of Object.entries(parsed.nodes)) {
        const h = this.nodes.get(url);
        if (!h) continue;
        if (typeof snap.latencyMs === 'number') h.latencyMs = snap.latencyMs;
        if (typeof snap.lastSuccessAt === 'number') h.lastSuccessAt = snap.lastSuccessAt;
      }
    } catch { /* corrupted storage — ignore */ }
  }

  private persist(): void {
    if (!this.storage) return;
    try {
      const snap: Record<string, Pick<NodeHealth, 'latencyMs' | 'lastSuccessAt'>> = {};
      for (const [url, h] of this.nodes) {
        snap[url] = { latencyMs: h.latencyMs, lastSuccessAt: h.lastSuccessAt };
      }
      this.storage.setItem(this.storageKey, JSON.stringify({ nodes: snap }));
    } catch { /* storage full or unavailable — ignore */ }
  }
}

export class RotatorError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'RotatorError';
  }
}

export class AllNodesDownError extends RotatorError {
  readonly attempts: { url: string; reason: string }[];
  constructor(attempts: { url: string; reason: string }[]) {
    const list = attempts.map(a => `  - ${a.url}: ${a.reason}`).join('\n');
    super(`All Steem nodes failed (${attempts.length} attempts):\n${list}`);
    this.name = 'AllNodesDownError';
    this.attempts = attempts;
  }
}

export class NodeRequestError extends RotatorError {
  readonly nodeUrl: string;
  readonly cause: unknown;
  constructor(nodeUrl: string, message: string, cause?: unknown) {
    super(`[${nodeUrl}] ${message}`);
    this.name = 'NodeRequestError';
    this.nodeUrl = nodeUrl;
    this.cause = cause;
  }
}

export class RpcError extends RotatorError {
  readonly code: number;
  readonly data: unknown;
  constructor(code: number, message: string, data?: unknown) {
    super(`RPC error ${code}: ${message}`);
    this.name = 'RpcError';
    this.code = code;
    this.data = data;
  }
}

export class TimeoutError extends RotatorError {
  constructor(ms: number, nodeUrl: string) {
    super(`Request to ${nodeUrl} timed out after ${ms} ms`);
    this.name = 'TimeoutError';
  }
}

import type { SteemRotator } from './rotator';

const DEFAULT_PROBE_METHOD = 'condenser_api.get_dynamic_global_properties';

export interface HealthCheckOptions {
  intervalMs?: number;
  probeMethod?: string;
  probeParams?: unknown;
  /** Run an immediate probe at start(). Default: true. */
  runImmediately?: boolean;
  /** Skip ticks while document.hidden is true. Default: true. */
  skipWhenHidden?: boolean;
  /** Per-probe timeout in ms. Default: 5000. */
  probeTimeoutMs?: number;
}

export class HealthCheckLoop {
  private readonly rotator: SteemRotator;
  private readonly intervalMs: number;
  private readonly probeMethod: string;
  private readonly probeParams: unknown;
  private readonly runImmediately: boolean;
  private readonly skipWhenHidden: boolean;
  private readonly probeTimeoutMs: number;
  private timer: ReturnType<typeof setInterval> | null = null;
  private running = false;

  constructor(rotator: SteemRotator, opts: HealthCheckOptions = {}) {
    this.rotator = rotator;
    this.intervalMs = opts.intervalMs ?? 5 * 60_000;
    this.probeMethod = opts.probeMethod ?? DEFAULT_PROBE_METHOD;
    this.probeParams = opts.probeParams ?? [];
    this.runImmediately = opts.runImmediately ?? true;
    this.skipWhenHidden = opts.skipWhenHidden ?? true;
    this.probeTimeoutMs = opts.probeTimeoutMs ?? 5_000;
  }

  start(): void {
    if (this.timer !== null) return;
    if (this.runImmediately) {
      void this.tick();
    }
    this.timer = setInterval(() => { void this.tick(); }, this.intervalMs);
  }

  stop(): void {
    if (this.timer !== null) {
      clearInterval(this.timer);
      this.timer = null;
    }
  }

  /** Probe every configured node once. Resolves when the round is finished. */
  async tick(): Promise<void> {
    if (this.running) return;
    if (this.skipWhenHidden && this.isHidden()) return;
    this.running = true;
    try {
      const nodes = this.rotator.nodes();
      await Promise.all(
        nodes.map(n =>
          this.rotator.probeNode(n.url, this.probeMethod, this.probeParams, this.probeTimeoutMs)
        )
      );
    } finally {
      this.running = false;
    }
  }

  private isHidden(): boolean {
    const d = (globalThis as { document?: { hidden?: boolean } }).document;
    return d?.hidden === true;
  }
}

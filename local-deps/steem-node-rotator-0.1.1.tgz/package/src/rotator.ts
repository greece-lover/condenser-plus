import type {
  RotatorConfig,
  CallOptions,
  NodeHealth,
  BroadcastSession
} from './types';
import { NodeHealthRegistry } from './registry';
import { AllNodesDownError, RpcError } from './errors';
import { rpcCall } from './transport';

const DEFAULTS = {
  healthCheckIntervalMs: 5 * 60_000,
  cooldownMs: 60_000,
  maxRetries: 3,
  timeoutMs: 8_000,
  pickStrategy: 'fastest-healthy' as const
};

export class SteemRotator {
  readonly registry: NodeHealthRegistry;
  private readonly cfg: Required<Omit<RotatorConfig,
    'storage' | 'storageKey' | 'fetchImpl' | 'onNodeFailure' | 'onNodeRecovery'>>
    & Pick<RotatorConfig,
    'storage' | 'storageKey' | 'fetchImpl' | 'onNodeFailure' | 'onNodeRecovery'>;

  constructor(config: RotatorConfig) {
    if (!config.nodes || config.nodes.length === 0) {
      throw new Error('SteemRotator: at least one node URL required');
    }
    this.cfg = {
      nodes: config.nodes,
      healthCheckIntervalMs: config.healthCheckIntervalMs ?? DEFAULTS.healthCheckIntervalMs,
      cooldownMs: config.cooldownMs ?? DEFAULTS.cooldownMs,
      maxRetries: config.maxRetries ?? DEFAULTS.maxRetries,
      timeoutMs: config.timeoutMs ?? DEFAULTS.timeoutMs,
      pickStrategy: config.pickStrategy ?? DEFAULTS.pickStrategy,
      storage: config.storage,
      storageKey: config.storageKey,
      fetchImpl: config.fetchImpl,
      onNodeFailure: config.onNodeFailure,
      onNodeRecovery: config.onNodeRecovery
    };
    this.registry = new NodeHealthRegistry(config.nodes, {
      cooldownMs: this.cfg.cooldownMs,
      storage: this.cfg.storage,
      storageKey: this.cfg.storageKey,
      pickStrategy: this.cfg.pickStrategy,
      onNodeFailure: this.cfg.onNodeFailure,
      onNodeRecovery: this.cfg.onNodeRecovery
    });
  }

  /** All nodes from the configured list with their current health snapshot. */
  nodes(): NodeHealth[] {
    return this.registry.list();
  }

  /**
   * Probe a single node directly — bypasses the rotation logic. Updates the
   * registry's health entry for that node based on the result. Used by
   * HealthCheckLoop for per-node measurements.
   */
  async probeNode(
    url: string,
    method: string = 'condenser_api.get_dynamic_global_properties',
    params: unknown = [],
    timeoutMs?: number
  ): Promise<{ ok: true; latencyMs: number } | { ok: false; reason: string }> {
    const fetchImpl = this.resolveFetch();
    try {
      const { latencyMs } = await rpcCall({
        url,
        method,
        params,
        timeoutMs: timeoutMs ?? this.cfg.timeoutMs,
        fetchImpl
      });
      this.registry.markHealthy(url, latencyMs);
      return { ok: true, latencyMs };
    } catch (err: unknown) {
      const e = err as { message?: string };
      const reason = e?.message ?? 'probe failed';
      // RPC errors from probe are still a node-side issue from our perspective:
      // if the standard probe method fails on a node, the node is unusable.
      this.registry.markUnhealthy(url, reason);
      return { ok: false, reason };
    }
  }

  private resolveFetch(): typeof fetch {
    const f = this.cfg.fetchImpl ?? globalThis.fetch;
    if (typeof f !== 'function') {
      throw new Error('No fetch implementation available. Pass fetchImpl in RotatorConfig.');
    }
    return f.bind(globalThis);
  }

  /**
   * Calls an RPC method, retrying on failure across the next eligible nodes.
   * Throws AllNodesDownError if all attempts fail.
   */
  async call<T = unknown>(method: string, params: unknown, options: CallOptions = {}): Promise<T> {
    const retries = options.retries ?? this.cfg.maxRetries;
    const timeoutMs = options.timeoutMs ?? this.cfg.timeoutMs;
    const fetchImpl = this.resolveFetch();

    const attempts: { url: string; reason: string }[] = [];
    const tried = new Set<string>();
    let lastRpcError: RpcError | null = null;

    for (let i = 0; i < retries; i++) {
      const candidates = this.registry.getEligible().filter(n => !tried.has(n.url));
      if (candidates.length === 0) break;
      const node = candidates[0];
      tried.add(node.url);

      try {
        const { result, latencyMs } = await rpcCall<T>({
          url: node.url,
          method,
          params,
          timeoutMs,
          fetchImpl,
          signal: options.signal
        });
        this.registry.markHealthy(node.url, latencyMs);
        return result;
      } catch (err: unknown) {
        const e = err as { message?: string; name?: string };
        const reason = e?.message ?? 'unknown error';
        attempts.push({ url: node.url, reason });

        // RPC-level errors (valid response, error field) usually mean the request
        // itself is bad — retrying on another node will fail the same way.
        if (err instanceof RpcError) {
          lastRpcError = err;
          // Do not mark unhealthy: the node responded fine, the request was rejected.
          break;
        }
        this.registry.markUnhealthy(node.url, reason);
      }
    }

    if (lastRpcError) throw lastRpcError;
    throw new AllNodesDownError(attempts);
  }

  /**
   * Begin a broadcast session pinned to a single node. The same node is used
   * for ref-block lookup AND the broadcast itself, preventing the
   * "ref_block_num seen on node A but tx submitted to node B" race.
   */
  beginBroadcastSession(): BroadcastSession {
    const node = this.registry.pickPreferred();
    if (!node) {
      throw new AllNodesDownError([{ url: '(none)', reason: 'no eligible node available' }]);
    }
    const fetchImpl = this.resolveFetch();
    const timeoutMs = this.cfg.timeoutMs;
    const registry = this.registry;
    let disposed = false;

    return {
      nodeUrl: node.url,
      async call<T = unknown>(method: string, params: unknown, options: CallOptions = {}): Promise<T> {
        if (disposed) throw new Error('BroadcastSession is disposed');
        try {
          const { result, latencyMs } = await rpcCall<T>({
            url: node.url,
            method,
            params,
            timeoutMs: options.timeoutMs ?? timeoutMs,
            fetchImpl,
            signal: options.signal
          });
          registry.markHealthy(node.url, latencyMs);
          return result;
        } catch (err: unknown) {
          if (!(err instanceof RpcError)) {
            const e = err as { message?: string };
            registry.markUnhealthy(node.url, e?.message ?? 'broadcast failure');
          }
          throw err;
        }
      },
      dispose() {
        disposed = true;
      }
    };
  }
}

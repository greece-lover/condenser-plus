export interface NodeHealth {
  url: string;
  isHealthy: boolean;
  latencyMs: number | null;
  lastSuccessAt: number | null;
  lastFailureAt: number | null;
  cooldownUntil: number | null;
  failureReason: string | null;
  consecutiveFailures: number;
}

export interface RotatorConfig {
  nodes: string[];
  healthCheckIntervalMs?: number;
  cooldownMs?: number;
  maxRetries?: number;
  timeoutMs?: number;
  storage?: PersistentStorage | null;
  storageKey?: string;
  fetchImpl?: typeof fetch;
  pickStrategy?: NodePickStrategy;
  onNodeFailure?: (info: NodeFailureInfo) => void;
  onNodeRecovery?: (info: NodeRecoveryInfo) => void;
}

export type NodePickStrategy = 'fastest-healthy' | 'round-robin' | 'first-healthy';

export interface NodeFailureInfo {
  url: string;
  reason: string;
  consecutiveFailures: number;
}

export interface NodeRecoveryInfo {
  url: string;
  latencyMs: number;
}

export interface PersistentStorage {
  getItem(key: string): string | null;
  setItem(key: string, value: string): void;
  removeItem(key: string): void;
}

export interface JsonRpcRequest {
  jsonrpc: '2.0';
  id: number;
  method: string;
  params: unknown;
}

export interface JsonRpcResponse<T = unknown> {
  jsonrpc: '2.0';
  id: number;
  result?: T;
  error?: { code: number; message: string; data?: unknown };
}

export interface CallOptions {
  timeoutMs?: number;
  retries?: number;
  signal?: AbortSignal;
}

export interface BroadcastSession {
  readonly nodeUrl: string;
  call<T = unknown>(method: string, params: unknown, options?: CallOptions): Promise<T>;
  dispose(): void;
}

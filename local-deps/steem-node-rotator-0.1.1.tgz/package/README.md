# steem-node-rotator

Multi-node failover and load balancing for Steem RPC nodes. Works in browsers and Node.js, has zero runtime dependencies, and is < 4 KB gzipped.

Public RPC nodes go down. They get slow. They lag behind on the chain. This library keeps that out of your application code: configure a list of nodes once, then call RPC methods as if there was just one node behind them.

Created by [@greece-lover](https://github.com/greece-lover), Steem witness operator.

## Install

```bash
npm install steem-node-rotator
```

Or load directly in a browser:

```html
<script src="https://unpkg.com/steem-node-rotator/dist/browser.js"></script>
<script>
  const { SteemRotator } = window.SteemNodeRotator;
</script>
```

## Quick start

### Browser

```js
import { SteemRotator } from 'steem-node-rotator';

const rotator = new SteemRotator({
  nodes: [
    'https://api.steemit.com',
    'https://api.steemyy.com',
    'https://api.justyy.com',
    'https://steem.nirmaha.com'
  ],
  storage: window.localStorage   // optional: remembers latencies between sessions
});

const props = await rotator.call('condenser_api.get_dynamic_global_properties', []);
console.log('Head block:', props.head_block_number);
```

If the first node fails, the call automatically retries on the next eligible node. Failed nodes are put in cooldown and skipped until they recover.

### Node.js

```js
const { SteemRotator } = require('steem-node-rotator');

const rotator = new SteemRotator({
  nodes: ['https://api.steemit.com', 'https://api.steemyy.com'],
  timeoutMs: 8000
});

const account = await rotator.call('condenser_api.get_accounts', [['ned']]);
```

Node.js 18+ ships `fetch` globally. On older Node, pass a fetch polyfill via `fetchImpl`.

## Why

If you have ever shipped a dApp on Steem, you have hit one of these:

- Default node is slow today, the user blames your app.
- Default node returns HTTP 503 for ten minutes, your app shows a blank screen.
- Broadcast fails because the node lost sync seconds ago, the user retries and you broadcast the same operation twice.

`steem-node-rotator` solves that by:

1. Keeping a health table for every configured node.
2. Picking the fastest healthy node for each call.
3. Falling over to the next node on network errors, with a cooldown on the failing one.
4. Pinning broadcasts to a single node (ref-block lookup and broadcast on the same node — no cross-node race).
5. Optionally caching last known latencies in `localStorage` so the first call after a page load is already pointed at the fastest node.

It is intentionally **not** a full RPC client. Bring your own helper for op serialization, signing, and crypto — this library only handles the routing layer.

## Configuration

```ts
new SteemRotator({
  nodes: string[],                 // required: at least one URL
  healthCheckIntervalMs?: number,  // default 300_000 (5 min)
  cooldownMs?: number,             // default 60_000  (1 min)
  maxRetries?: number,             // default 3
  timeoutMs?: number,              // default 8_000
  storage?: PersistentStorage|null,// localStorage, sessionStorage, or any { getItem, setItem, removeItem }
  storageKey?: string,             // default 'steem-node-rotator:health'
  fetchImpl?: typeof fetch,        // override the global fetch (e.g. node-fetch on old Node)
  pickStrategy?: 'fastest-healthy' | 'round-robin' | 'first-healthy', // default fastest-healthy
  onNodeFailure?: ({ url, reason, consecutiveFailures }) => void,
  onNodeRecovery?: ({ url, latencyMs }) => void
})
```

### Pick strategies

| Strategy | When to use |
| --- | --- |
| `fastest-healthy` *(default)* | Best for end-user apps. Uses the lowest measured latency, falls back to unmeasured nodes. |
| `round-robin` | Spreads load evenly across nodes. Good for read-heavy services. |
| `first-healthy` | Strict priority by configured order. Useful when one node is preferred and others are fallbacks. |

## Failover behavior

A `rotator.call(method, params)` will:

1. Pick the preferred eligible node.
2. Call it.
3. On a **network/timeout/HTTP failure**: mark it unhealthy with cooldown, retry on the next node, up to `maxRetries` total attempts.
4. On a **JSON-RPC error response** (the node replied, but with `{ error: { code, message } }`): do **not** retry. The request itself is bad — another node will reject it the same way. The node stays healthy.
5. If every attempt fails: throw `AllNodesDownError` with the per-node failure reasons.

```js
import { AllNodesDownError, RpcError } from 'steem-node-rotator';

try {
  const r = await rotator.call('condenser_api.get_accounts', [['someone']]);
} catch (err) {
  if (err instanceof AllNodesDownError) {
    // every node we tried failed at the network level
    err.attempts.forEach(a => console.warn(a.url, a.reason));
  } else if (err instanceof RpcError) {
    // the request itself was rejected (bad params, unknown method, …)
    console.error('RPC error', err.code, err.message);
  } else {
    throw err;
  }
}
```

## Sticky broadcasts

Broadcasting a transaction is a two-step pattern: read a recent block reference, sign the tx, send it. Doing those two RPC calls on different nodes is a known footgun — node A might be ahead of node B, and your tx ends up referencing a block node B has not yet seen.

Use a broadcast session to pin both calls to the same node:

```js
const session = rotator.beginBroadcastSession();
try {
  const props = await session.call('condenser_api.get_dynamic_global_properties', []);
  const tx = buildAndSignTx(props, ops);                         // your code
  await session.call('condenser_api.broadcast_transaction', [tx]);
} finally {
  session.dispose();
}
```

Broadcast failures are **not** retried across nodes. That is intentional: it prevents the worst-case "tx sent twice because the response was lost in flight" outcome. If the broadcast fails, surface the error to the user; let them retry explicitly.

## Background health checks

Run a periodic loop that probes every node so the next user call already knows which one is fastest:

```js
import { SteemRotator, HealthCheckLoop } from 'steem-node-rotator';

const rotator = new SteemRotator({ nodes: [...] });
const loop = new HealthCheckLoop(rotator, {
  intervalMs: 5 * 60_000,    // every 5 minutes
  skipWhenHidden: true       // don't probe when the browser tab is hidden (saves battery)
});
loop.start();
// later: loop.stop();
```

The probe is a single, cheap RPC call (`condenser_api.get_dynamic_global_properties`). Override with `probeMethod` / `probeParams` if you prefer a different endpoint.

## Mobile and battery

The defaults are deliberately conservative for mobile devices:

- Health checks default to once every 5 minutes.
- `skipWhenHidden: true` (default) means hidden tabs don't probe at all.
- `storage` (when set) preserves last known latencies across sessions, so the next page load can pick the fastest node without a probe round.

For mobile-first PWAs, also consider:

```js
const loop = new HealthCheckLoop(rotator, {
  intervalMs: navigator.connection?.effectiveType === '4g' ? 5 * 60_000 : 15 * 60_000
});
```

## TypeScript

Full type definitions ship in the package — no `@types/...` install needed.

## Testing your integration

`steem-node-rotator` accepts a custom `fetchImpl`. In your tests, pass a stub:

```js
const rotator = new SteemRotator({
  nodes: ['https://example.test'],
  fetchImpl: async () =>
    new Response(JSON.stringify({ jsonrpc: '2.0', id: 1, result: { ok: true } }))
});
```

## Contributing

Issues and PRs welcome at <https://github.com/greece-lover/steem-node-rotator>. See [CONTRIBUTING.md](CONTRIBUTING.md).

## License

MIT — see [LICENSE](LICENSE).
